<?php

namespace App\Filament\Resources\DeviceResource\Pages;

use App\Filament\Resources\DeviceResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditDevice extends EditRecord
{
    protected static string $resource = DeviceResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }

    //VOLVER A INDEX DESPUES DE ACTUALIZAR
    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }
}
