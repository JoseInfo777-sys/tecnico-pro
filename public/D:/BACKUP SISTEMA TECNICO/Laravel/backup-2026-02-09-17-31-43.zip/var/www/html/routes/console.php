<?php

use Illuminate\Support\Facades\Schedule;
use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// Programar el backup todos los domingos a las 11:00 PM
Schedule::command('backup:run')->weeklyOn(0, '23:00');

// Opcional: Limpiar backups viejos para no llenar el disco (lunes a las 1:00 AM)
Schedule::command('backup:clean')->weeklyOn(1, '01:00');
